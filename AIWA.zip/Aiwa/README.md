### ABOUT AIWA

- It is a AI based virtual workout assitant. Which will help you in your workout sessions.

## SOME OF THE FEATURES

- It will show you how many reps of a exercise you have completed.
- It will provide you with insights, like the amount of calories you have burnt.
- It will also detect if there are any mistakes in your postrue while doing your workouts.